package spreadsheet;

/**
 * a inteface for command.
 */
public interface ICommand {
  void execute(SpreadSheet s);
}
