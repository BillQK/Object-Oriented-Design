import org.junit.Test;

import static org.junit.Assert.*;

public class ValueTest {

  @Test
  public void testToString() {
  }

  @Test
  public void getValue() {
  }

  @Test
  public void isOneGreater() {
  }

  @Test
  public void isOneLower() {
  }
}