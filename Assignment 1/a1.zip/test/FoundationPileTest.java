import org.junit.Test;

import static org.junit.Assert.*;

public class FoundationPileTest {

  @Test
  public void canBeAdded() {
  }

  @Test
  public void validPile() {
  }

  @Test
  public void isFull() {
  }
}