import org.junit.Test;

import static org.junit.Assert.*;

public class FoundationPileTest {

  @Test
  public void canBeAdded() {
  }

  @Test
  public void canAddListCard() {
  }

  @Test
  public void validPile() {
  }

  @Test
  public void getMoveCards() {
  }

  @Test
  public void isFull() {
  }
}