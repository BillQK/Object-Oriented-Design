import org.junit.Test;

import cs3500.freecell.model.Card;
import cs3500.freecell.model.CascadePile;
import cs3500.freecell.model.Pile;
import cs3500.freecell.model.Suit;
import cs3500.freecell.model.Value;

import static org.junit.Assert.assertTrue;

public class CascadePileTest {
  /**
   * Initialize the Pile.
   */
  Pile cascadePile = new CascadePile();

  @Test
  public void canBeAdded() {
    assertTrue(cascadePile.canBeAdded(new Card(Value.TWO, Suit.HEART)));
  }

  @Test
  public void validPile() {
  }


}