import org.junit.Test;

import static org.junit.Assert.*;

public class OpenPileTest {

  @Test
  public void canBeAdded() {
  }

  @Test
  public void canAddListCard() {
  }

  @Test
  public void validPile() {
  }

  @Test
  public void getMoveCards() {
  }
}