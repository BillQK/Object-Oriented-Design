import org.junit.Test;

import static org.junit.Assert.*;

public class SuitTest {

  @Test
  public void getGraf() {
  }

  @Test
  public void testToString() {
  }

  @Test
  public void isSameType() {
  }

  @Test
  public void isDifferentColor() {
  }

  @Test
  public void values() {
  }

  @Test
  public void valueOf() {
  }
}