package cs3500.freecell.model;

/**
 * Represent the color of the card.
 */
public enum Color {
  BLACK, RED;

}
